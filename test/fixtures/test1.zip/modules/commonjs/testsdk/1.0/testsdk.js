module.exports = (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
exports.authFunctionName = 'login';

exports.createAuthObject = function(opts) {
	opts = opts || {};
	opts.username = opts.username || '';
	opts.password = opts.password || '';
	opts.securityToken = opts.securityToken || '';

	return opts;
};

exports.processResult = function(api, result) {
	if (result) {
		api.authObject = {
			accessToken: result.accessToken
		};
	}
};

exports.transformUrl = function(url, opts) {
	opts = opts || {};
	opts.accessToken = opts.accessToken || '';

	return url + '?accessToken=' + opts.accessToken;
};
},{}],2:[function(require,module,exports){
var util = require('./util');

var auth_salesforce = require("./auth/salesforce");

var baseFns = ['readOne', 'readAll', 'create', 'update', 'delete'];

// BASE API CLASS
function BaseApi() {}
baseFns.forEach(function(fn) {
	BaseApi.prototype[fn] = function() {
		throw new Error(fn + '() not implemented');
	};
});

// sync() implementation
function createSync(api) {
	return function sync(method, model, options) {
		options = options || {};

		var id = options.id;

		function done(err, result) {
			return err ? options.error(err) : options.success(result);
		}

		switch (method) {
			case "read":
				if (id || id === 0) {
					api.readOne(id, done);
				} else {
					api.readAll(done);
				}
				break;
			case "create":
				api.create(model, done);
				break;
			case "update":
				api.update(id, model, done);
				break;
			case "delete":
				api.delete(id, done);
				break;
		}
	};
}

// MobilewareApiCustomer CLASS
function MobilewareApiCustomer() {
	var self = this,
		namespaces = {
			"item": {},
			"custom": {
				"super": {
					"ultra": {}
				}
			}
		};

	// create API namespace structure
	Object.keys(namespaces).forEach(function(key) {
		self[key] = namespaces[key];
	});
	this.name = 'customer';
	this.version = '1.3';

	// API implementation
	this.readAll = function(opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer', self.authObject), 'GET', null, opts, callback);
	};

	this.readOne = function(id, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer' + '/' + id, self.authObject), 'GET', null, opts, callback);
	};

	this['item'].readAll = function(customer_id, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer' + '/' + customer_id + '/' + 'item', self.authObject), 'GET', null, opts, callback);
	};

	this['item'].readOne = function(customer_id, item_id, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer' + '/' + customer_id + '/' + 'item' + '/' + item_id, self.authObject), 'GET', null, opts, callback);
	};

	this.update = function(id, model, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer' + '/' + id, self.authObject), 'POST', model, opts, callback);
	};

	this.create = function(model, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer', self.authObject), 'PUT', model, opts, callback);
	};

	this.delete = function(id, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer' + '/' + id, self.authObject), 'DELETE', null, opts, callback);
	};

	this['item'].delete = function(customer_id, item_id, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('customer' + '/' + customer_id + '/' + 'item' + '/' + item_id, self.authObject), 'DELETE', null, opts, callback);
	};

	this['custom']['super']['ultra'].api = function(model, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest(auth_salesforce.transformUrl('custom' + '/' + 'super' + '/' + 'ultra' + '/' + 'api', self.authObject), 'POST', model, opts, callback);
	};

	this.login = function(model, opts, callback) {
		callback = util.maybeCallback(arguments[arguments.length - 1]);
		if (!opts || util.isFunction(opts)) {
			opts = {};
		}
		makeRequest('login', 'POST', auth_salesforce.createAuthObject(model), opts, function(err, result) {
			if (!err) {
				auth_salesforce.processResult(self, result);
			}
			return callback(err, result);
		});
	};

	// Backbone sync
	this.sync = createSync(this);
}

MobilewareApiCustomer.prototype = Object.create(BaseApi.prototype);
MobilewareApiCustomer.prototype.constructor = MobilewareApiCustomer;

// SDK CLASS
function MobilewareSdk() {
	this.name = "testsdk";
	this.version = "1.0";
	this.organization = "appcelerator";
	this.url = "https://localhost:54321";
	this.apis = {};

	// API: customer
	this.apis["customer"] = new MobilewareApiCustomer();

}

MobilewareSdk.prototype.api = function api(name) {
	var apiObj = this.apis[name];
	if (!apiObj) {
		throw new Error('unknown api "' + name + '"');
	}
	return apiObj;
};

MobilewareSdk.prototype.toString = function toString() {
	return JSON.stringify(this, function(key, value) {
		if (typeof value === 'function') {
			var func = value.toString();
			return func.substring(0, func.indexOf(')') + 1);
		}
		return value;
	}, '  ');
};

module.exports = new MobilewareSdk();

function makeRequest(url, method, data, opts, callback) {
	callback = util.maybeCallback(arguments[arguments.length - 1]);
	if (util.isFunction(data)) {
		data = undefined;
	}

	var httpOpts = {

		onload: function(e) {
			var response;
			try {
				response = JSON.parse(this.responseText);
			} catch (ex) {
				return callback('request error: ' + ex.toString(), null, e);
			}
			return callback(null, response, e);
		},
		onerror: function(e) {
			return callback('(' + this.status + ') ' + e.error + '\n' + this.responseText, null, e);
		}
	};
	Object.keys(opts).forEach(function(opt) {
		httpOpts[opt] = opts[opt];
	});

	var client = Ti.Network.createHTTPClient(httpOpts);
	client.open(method, module.exports.url + '/' + url);
	if (data) {
		client.setRequestHeader('Content-Type', 'application/json');
		client.send(JSON.stringify(data));
	} else {
		client.send();
	}
}
},{"./auth/salesforce":1,"./util":3}],3:[function(require,module,exports){
exports.maybeCallback = function maybeCallback(cb) {
	return cb && exports.isFunction(cb) ? cb : function(err) { if (err) { throw err; } };
};

var types = ['Array','String','Boolean','Number','Function','Date'];
types.forEach(function(type) {
	exports['is' + type] = function(o) {
		return Object.prototype.toString.call(o) === '[object ' + type + ']';
	};
});

exports.isObject = function(o) {
	return o === Object(o);
};

function s4() {
	return Math.floor((1+Math.random())*0x10000).toString(16).substring(1);
}

exports.guid = function() {
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
};

},{}]},{},[2])(2);