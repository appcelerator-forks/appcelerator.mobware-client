module.exports = (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var util = require('./util');



var baseFns = ['readOne', 'readAll', 'create', 'update', 'delete'];

// BASE API CLASS
function BaseApi() {}
baseFns.forEach(function(fn) {
	BaseApi.prototype[fn] = function() {
		throw new Error(fn + '() not implemented');
	};
});

// sync() implementation
function createSync(api) {
	return function sync(method, model, options) {
		options = options || {};

		var id = options.id;

		function done(err, result) {
			return err ? options.error(err) : options.success(result);
		}

		switch (method) {
			case "read":
				if (id || id === 0) {
					api.readOne(id, done);
				} else {
					api.readAll(done);
				}
				break;
			case "create":
				api.create(model, done);
				break;
			case "update":
				api.update(id, model, done);
				break;
			case "delete":
				api.delete(id, done);
				break;
		}
	};
}

// SDK CLASS
function MobilewareSdk() {
	this.name = "test2";
	this.version = "0.3.1";
	this.organization = "appcelerator";
	this.url = "https://localhost:54321";
	this.apis = {};

}

MobilewareSdk.prototype.api = function api(name) {
	var apiObj = this.apis[name];
	if (!apiObj) {
		throw new Error('unknown api "' + name + '"');
	}
	return apiObj;
};

MobilewareSdk.prototype.toString = function toString() {
	return JSON.stringify(this, function(key, value) {
		if (typeof value === 'function') {
			var func = value.toString();
			return func.substring(0, func.indexOf(')') + 1);
		}
		return value;
	}, '  ');
};

module.exports = new MobilewareSdk();

function makeRequest(url, method, data, opts, callback) {
	callback = util.maybeCallback(arguments[arguments.length - 1]);
	if (util.isFunction(data)) {
		data = undefined;
	}

	var httpOpts = {

		onload: function(e) {
			var response;
			try {
				response = JSON.parse(this.responseText);
			} catch (ex) {
				return callback('request error: ' + ex.toString(), null, e);
			}
			return callback(null, response, e);
		},
		onerror: function(e) {
			return callback('(' + this.status + ') ' + e.error + '\n' + this.responseText, null, e);
		}
	};
	Object.keys(opts).forEach(function(opt) {
		httpOpts[opt] = opts[opt];
	});

	var client = Ti.Network.createHTTPClient(httpOpts);
	client.open(method, module.exports.url + '/' + url);
	if (data) {
		client.setRequestHeader('Content-Type', 'application/json');
		client.send(JSON.stringify(data));
	} else {
		client.send();
	}
}
},{"./util":2}],2:[function(require,module,exports){
exports.maybeCallback = function maybeCallback(cb) {
	return cb && exports.isFunction(cb) ? cb : function(err) { if (err) { throw err; } };
};

var types = ['Array','String','Boolean','Number','Function','Date'];
types.forEach(function(type) {
	exports['is' + type] = function(o) {
		return Object.prototype.toString.call(o) === '[object ' + type + ']';
	};
});

exports.isObject = function(o) {
	return o === Object(o);
};

function s4() {
	return Math.floor((1+Math.random())*0x10000).toString(16).substring(1);
}

exports.guid = function() {
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
};

},{}]},{},[1])(1);